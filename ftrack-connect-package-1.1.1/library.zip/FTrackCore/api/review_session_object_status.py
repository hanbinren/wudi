# :coding: utf-8
# :copyright: Copyright (c) 2015 ftrack

from .ftobject import FTObject


class ReviewSessionObjectStatus(FTObject):
    '''Represent review session invitee.'''

    _type = 'reviewsessionobjectstatus'
